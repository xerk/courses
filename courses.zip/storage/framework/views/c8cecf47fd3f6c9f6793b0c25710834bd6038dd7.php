<div <?php echo e($attributes->merge(['class' => 'px-4 my-2'])); ?>>
    <?php echo e($slot); ?>

</div><?php /**PATH G:\Laravel\courses\resources\views/components/inputs/group.blade.php ENDPATH**/ ?>