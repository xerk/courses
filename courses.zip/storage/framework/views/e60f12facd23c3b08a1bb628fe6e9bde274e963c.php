<div wire:poll.<?php echo e(config('filament-spatie-laravel-backup.polling.interval') ?? '4s'); ?>>
	<?php echo e($this->table); ?>

</div>
<?php /**PATH G:\Laravel\courses\vendor\shuvroroy\filament-spatie-laravel-backup\src\/../resources/views/components/backup-destination-list-records.blade.php ENDPATH**/ ?>