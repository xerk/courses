<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            <?php echo app('translator')->get('crud.users.show_title'); ?>
        </h2>
     <?php $__env->endSlot(); ?>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.partials.card','data' => []] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('partials.card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
                 <?php $__env->slot('title', null, []); ?> 
                    <a href="<?php echo e(route('users.index')); ?>" class="mr-4"
                        ><i class="mr-1 icon ion-md-arrow-back"></i
                    ></a>
                 <?php $__env->endSlot(); ?>

                <div class="mt-4 px-4">
                    <div class="mb-4">
                        <h5 class="font-medium text-gray-700">
                            <?php echo app('translator')->get('crud.users.inputs.name_en'); ?>
                        </h5>
                        <span><?php echo e($user->name_en ?? '-'); ?></span>
                    </div>
                    <div class="mb-4">
                        <h5 class="font-medium text-gray-700">
                            <?php echo app('translator')->get('crud.users.inputs.name_ar'); ?>
                        </h5>
                        <span><?php echo e($user->name_ar ?? '-'); ?></span>
                    </div>
                    <div class="mb-4">
                        <h5 class="font-medium text-gray-700">
                            <?php echo app('translator')->get('crud.users.inputs.avatar'); ?>
                        </h5>
                        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.partials.thumbnail','data' => ['src' => ''.e($user->avatar ? \Storage::url($user->avatar) : '').'','size' => '150']] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('partials.thumbnail'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['src' => ''.e($user->avatar ? \Storage::url($user->avatar) : '').'','size' => '150']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                    </div>
                    <div class="mb-4">
                        <h5 class="font-medium text-gray-700">
                            <?php echo app('translator')->get('crud.users.inputs.email'); ?>
                        </h5>
                        <span><?php echo e($user->email ?? '-'); ?></span>
                    </div>
                    <div class="mb-4">
                        <h5 class="font-medium text-gray-700">
                            <?php echo app('translator')->get('crud.users.inputs.private_email'); ?>
                        </h5>
                        <span><?php echo e($user->private_email ?? '-'); ?></span>
                    </div>
                    <div class="mb-4">
                        <h5 class="font-medium text-gray-700">
                            <?php echo app('translator')->get('crud.users.inputs.phone'); ?>
                        </h5>
                        <span><?php echo e($user->phone ?? '-'); ?></span>
                    </div>
                    <div class="mb-4">
                        <h5 class="font-medium text-gray-700">
                            <?php echo app('translator')->get('crud.users.inputs.phone2'); ?>
                        </h5>
                        <span><?php echo e($user->phone2 ?? '-'); ?></span>
                    </div>
                    <div class="mb-4">
                        <h5 class="font-medium text-gray-700">
                            <?php echo app('translator')->get('crud.users.inputs.address'); ?>
                        </h5>
                        <span><?php echo e($user->address ?? '-'); ?></span>
                    </div>
                    <div class="mb-4">
                        <h5 class="font-medium text-gray-700">
                            <?php echo app('translator')->get('crud.users.inputs.inside_address'); ?>
                        </h5>
                        <span><?php echo e($user->inside_address ?? '-'); ?></span>
                    </div>
                    <div class="mb-4">
                        <h5 class="font-medium text-gray-700">
                            <?php echo app('translator')->get('crud.users.inputs.type'); ?>
                        </h5>
                        <span><?php echo e($user->type ?? '-'); ?></span>
                    </div>
                    <div class="mb-4">
                        <h5 class="font-medium text-gray-700">
                            <?php echo app('translator')->get('crud.users.inputs.category_id'); ?>
                        </h5>
                        <span
                            ><?php echo e(optional($user->category)->name ?? '-'); ?></span
                        >
                    </div>
                    <div class="mb-4">
                        <h5 class="font-medium text-gray-700">
                            <?php echo app('translator')->get('crud.users.inputs.city'); ?>
                        </h5>
                        <span><?php echo e($user->city ?? '-'); ?></span>
                    </div>
                    <div class="mb-4">
                        <h5 class="font-medium text-gray-700">
                            <?php echo app('translator')->get('crud.users.inputs.country'); ?>
                        </h5>
                        <span><?php echo e($user->country ?? '-'); ?></span>
                    </div>
                    <div class="mb-4">
                        <h5 class="font-medium text-gray-700">
                            <?php echo app('translator')->get('crud.users.inputs.company_id'); ?>
                        </h5>
                        <span><?php echo e(optional($user->company)->name ?? '-'); ?></span>
                    </div>
                </div>

                <div class="mt-4 px-4">
                    <div class="mb-4">
                        <h5 class="font-medium text-gray-700">
                            <?php echo app('translator')->get('crud.roles.name'); ?>
                        </h5>
                        <div>
                            <?php $__empty_1 = true; $__currentLoopData = $user->roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <div
                                class="
                                    inline-block
                                    p-1
                                    text-center text-sm
                                    rounded
                                    bg-blue-400
                                    text-white
                                "
                            >
                                <?php echo e($role->name); ?>

                            </div>
                            <br />
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?> - <?php endif; ?>
                        </div>
                    </div>
                </div>

                <div class="mt-10">
                    <a href="<?php echo e(route('users.index')); ?>" class="button">
                        <i class="mr-1 icon ion-md-return-left"></i>
                        <?php echo app('translator')->get('crud.common.back'); ?>
                    </a>

                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('create', App\Models\User::class)): ?>
                    <a href="<?php echo e(route('users.create')); ?>" class="button">
                        <i class="mr-1 icon ion-md-add"></i>
                        <?php echo app('translator')->get('crud.common.create'); ?>
                    </a>
                    <?php endif; ?>
                </div>
             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php /**PATH G:\Laravel\courses\resources\views/app/users/show.blade.php ENDPATH**/ ?>