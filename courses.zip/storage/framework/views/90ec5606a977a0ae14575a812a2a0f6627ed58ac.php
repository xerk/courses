<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            <?php echo app('translator')->get('crud.users.index_title'); ?>
        </h2>
     <?php $__env->endSlot(); ?>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.partials.card','data' => []] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('partials.card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
                <div class="mb-5 mt-4">
                    <div class="flex flex-wrap justify-between">
                        <div class="md:w-1/2">
                            <form>
                                <div class="flex items-center w-full">
                                    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.inputs.text','data' => ['name' => 'search','value' => ''.e($search ?? '').'','placeholder' => ''.e(__('crud.common.search')).'','autocomplete' => 'off']] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('inputs.text'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'search','value' => ''.e($search ?? '').'','placeholder' => ''.e(__('crud.common.search')).'','autocomplete' => 'off']); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>

                                    <div class="ml-1">
                                        <button
                                            type="submit"
                                            class="button button-primary"
                                        >
                                            <i class="icon ion-md-search"></i>
                                        </button>
                                    </div>
                                </div>
                            </form>
                        </div>
                        <div class="md:w-1/2 text-right">
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('create', App\Models\User::class)): ?>
                            <a
                                href="<?php echo e(route('users.create')); ?>"
                                class="button button-primary"
                            >
                                <i class="mr-1 icon ion-md-add"></i>
                                <?php echo app('translator')->get('crud.common.create'); ?>
                            </a>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>

                <div class="block w-full overflow-auto scrolling-touch">
                    <table class="w-full max-w-full mb-4 bg-transparent">
                        <thead class="text-gray-700">
                            <tr>
                                <th class="px-4 py-3 text-left">
                                    <?php echo app('translator')->get('crud.users.inputs.name'); ?>
                                </th>
                                <th class="px-4 py-3 text-left">
                                    <?php echo app('translator')->get('crud.users.inputs.name_ar'); ?>
                                </th>
                                <th class="px-4 py-3 text-left">
                                    <?php echo app('translator')->get('crud.users.inputs.avatar'); ?>
                                </th>
                                <th class="px-4 py-3 text-left">
                                    <?php echo app('translator')->get('crud.users.inputs.email'); ?>
                                </th>
                                <th class="px-4 py-3 text-left">
                                    <?php echo app('translator')->get('crud.users.inputs.private_email'); ?>
                                </th>
                                <th class="px-4 py-3 text-left">
                                    <?php echo app('translator')->get('crud.users.inputs.phone'); ?>
                                </th>
                                <th class="px-4 py-3 text-left">
                                    <?php echo app('translator')->get('crud.users.inputs.phone2'); ?>
                                </th>
                                <th class="px-4 py-3 text-left">
                                    <?php echo app('translator')->get('crud.users.inputs.address'); ?>
                                </th>
                                <th class="px-4 py-3 text-left">
                                    <?php echo app('translator')->get('crud.users.inputs.inside_address'); ?>
                                </th>
                                <th class="px-4 py-3 text-left">
                                    <?php echo app('translator')->get('crud.users.inputs.type'); ?>
                                </th>
                                <th class="px-4 py-3 text-left">
                                    <?php echo app('translator')->get('crud.users.inputs.category_id'); ?>
                                </th>
                                <th class="px-4 py-3 text-left">
                                    <?php echo app('translator')->get('crud.users.inputs.city'); ?>
                                </th>
                                <th class="px-4 py-3 text-left">
                                    <?php echo app('translator')->get('crud.users.inputs.country'); ?>
                                </th>
                                <th class="px-4 py-3 text-left">
                                    <?php echo app('translator')->get('crud.users.inputs.company_id'); ?>
                                </th>
                                <th></th>
                            </tr>
                        </thead>
                        <tbody class="text-gray-600">
                            <?php $__empty_1 = true; $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr class="hover:bg-gray-50">
                                <td class="px-4 py-3 text-left">
                                    <?php echo e($user->name ?? '-'); ?>

                                </td>
                                <td class="px-4 py-3 text-left">
                                    <?php echo e($user->name_ar ?? '-'); ?>

                                </td>
                                <td class="px-4 py-3 text-left">
                                    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.partials.thumbnail','data' => ['src' => ''.e($user->avatar ? \Storage::url($user->avatar) : '').'']] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('partials.thumbnail'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['src' => ''.e($user->avatar ? \Storage::url($user->avatar) : '').'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                                </td>
                                <td class="px-4 py-3 text-left">
                                    <?php echo e($user->email ?? '-'); ?>

                                </td>
                                <td class="px-4 py-3 text-left">
                                    <?php echo e($user->private_email ?? '-'); ?>

                                </td>
                                <td class="px-4 py-3 text-left">
                                    <?php echo e($user->phone ?? '-'); ?>

                                </td>
                                <td class="px-4 py-3 text-left">
                                    <?php echo e($user->phone2 ?? '-'); ?>

                                </td>
                                <td class="px-4 py-3 text-left">
                                    <?php echo e($user->address ?? '-'); ?>

                                </td>
                                <td class="px-4 py-3 text-left">
                                    <?php echo e($user->inside_address ?? '-'); ?>

                                </td>
                                <td class="px-4 py-3 text-left">
                                    <?php echo e($user->type ?? '-'); ?>

                                </td>
                                <td class="px-4 py-3 text-left">
                                    <?php echo e(optional($user->category)->name ?? '-'); ?>

                                </td>
                                <td class="px-4 py-3 text-left">
                                    <?php echo e($user->city ?? '-'); ?>

                                </td>
                                <td class="px-4 py-3 text-left">
                                    <?php echo e($user->country ?? '-'); ?>

                                </td>
                                <td class="px-4 py-3 text-left">
                                    <?php echo e(optional($user->company)->name ?? '-'); ?>

                                </td>
                                <td
                                    class="px-4 py-3 text-center"
                                    style="width: 134px;"
                                >
                                    <div
                                        role="group"
                                        aria-label="Row Actions"
                                        class="
                                            relative
                                            inline-flex
                                            align-middle
                                        "
                                    >
                                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('update', $user)): ?>
                                        <a
                                            href="<?php echo e(route('users.edit', $user)); ?>"
                                            class="mr-1"
                                        >
                                            <button
                                                type="button"
                                                class="button"
                                            >
                                                <i
                                                    class="icon ion-md-create"
                                                ></i>
                                            </button>
                                        </a>
                                        <?php endif; ?> <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view', $user)): ?>
                                        <a
                                            href="<?php echo e(route('users.show', $user)); ?>"
                                            class="mr-1"
                                        >
                                            <button
                                                type="button"
                                                class="button"
                                            >
                                                <i class="icon ion-md-eye"></i>
                                            </button>
                                        </a>
                                        <?php endif; ?> <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('delete', $user)): ?>
                                        <form
                                            action="<?php echo e(route('users.destroy', $user)); ?>"
                                            method="POST"
                                            onsubmit="return confirm('<?php echo e(__('crud.common.are_you_sure')); ?>')"
                                        >
                                            <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                                            <button
                                                type="submit"
                                                class="button"
                                            >
                                                <i
                                                    class="
                                                        icon
                                                        ion-md-trash
                                                        text-red-600
                                                    "
                                                ></i>
                                            </button>
                                        </form>
                                        <?php endif; ?>
                                    </div>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="15">
                                    <?php echo app('translator')->get('crud.common.no_items_found'); ?>
                                </td>
                            </tr>
                            <?php endif; ?>
                        </tbody>
                        <tfoot>
                            <tr>
                                <td colspan="15">
                                    <div class="mt-10 px-4">
                                        <?php echo $users->render(); ?>

                                    </div>
                                </td>
                            </tr>
                        </tfoot>
                    </table>
                </div>
             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php /**PATH G:\Laravel\courses\resources\views/app/users/index.blade.php ENDPATH**/ ?>