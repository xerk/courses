<?php echo e(\Filament\Facades\Filament::renderHook('footer.before')); ?>


<div class="filament-footer flex items-center justify-center">
    <?php echo e(\Filament\Facades\Filament::renderHook('footer.start')); ?>


    <?php if(config('filament.layout.footer.should_show_logo')): ?>
        <a
            href="https://linkedin.com/in/xerk"
            target="_blank"
            rel="noopener noreferrer"
            class="text-gray-300 hover:text-primary-500 transition"
        >
            Developed by XERK
        </a>
    <?php endif; ?>

    <?php echo e(\Filament\Facades\Filament::renderHook('footer.end')); ?>

</div>

<?php echo e(\Filament\Facades\Filament::renderHook('footer.after')); ?>

<?php /**PATH G:\Laravel\courses\resources\views/vendor/filament/components/footer.blade.php ENDPATH**/ ?>