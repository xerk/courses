<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag; ?>
<?php foreach($attributes->onlyProps([
    'src',
    'size' => 50,
]) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $attributes = $attributes->exceptProps([
    'src',
    'size' => 50,
]); ?>
<?php foreach (array_filter(([
    'src',
    'size' => 50,
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>

<?php if($src): ?>
<img src="<?php echo e($src); ?>" class="object-cover rounded border border-gray-200" style="width: <?php echo e($size); ?>px; height: <?php echo e($size); ?>px;">
<?php else: ?>
<div class="border rounded border-gray-200 bg-gray-100" style="width: <?php echo e($size); ?>px; height: <?php echo e($size); ?>px;"></div>
<?php endif; ?><?php /**PATH G:\Laravel\courses\resources\views/components/partials/thumbnail.blade.php ENDPATH**/ ?>